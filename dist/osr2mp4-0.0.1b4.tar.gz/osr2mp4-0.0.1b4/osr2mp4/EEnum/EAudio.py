from enum import IntEnum


class Sound(IntEnum):
	normalset = 0
	additionalset = 1
	index = 2
	volume = 3
	filename = 4
