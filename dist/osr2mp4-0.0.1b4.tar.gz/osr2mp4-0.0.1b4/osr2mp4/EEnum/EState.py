from enum import IntEnum


class States(IntEnum):
	NORMAL = 0
	NOTELOCK = 1
	FADEOUT = 2
