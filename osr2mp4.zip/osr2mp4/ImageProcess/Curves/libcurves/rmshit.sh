rm -r build/
rm -r cmake-build-debug/
rm ccurves.cpython-37m-darwin.so
rm -r __pycache__
rm ccurves.cpp
