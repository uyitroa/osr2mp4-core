class HitObject:
	diff = None
	mods = None
