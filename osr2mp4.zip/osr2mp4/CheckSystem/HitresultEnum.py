from enum import Enum


class Resulthit(Enum):
	Miss = 0
	Meh = 50
	Good = 100
	Great = 300
