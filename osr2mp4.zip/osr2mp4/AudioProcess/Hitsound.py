class Hitsound:
	hitsounds = {}
	miss = None
	spinnerbonus = None
	spinnerspin = []
	sectionfail = None
	sectionpass = None
