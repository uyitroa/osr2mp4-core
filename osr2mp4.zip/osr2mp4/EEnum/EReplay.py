from enum import IntEnum


class Replays(IntEnum):
	CURSOR_X = 0
	CURSOR_Y = 1
	KEYS_PRESSED = 2
	TIMES = 3
